
public class TestQuota {

}
